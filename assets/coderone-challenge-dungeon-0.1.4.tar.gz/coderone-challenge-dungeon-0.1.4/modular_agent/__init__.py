from . import stand_still

def agent():
	return stand_still.agent()